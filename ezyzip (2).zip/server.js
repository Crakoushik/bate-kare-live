const express = require('express');
const app = express();
const http = require('http').createServer(app);

http.listen(process.env.Port || 3000, () => {
    console.log("Listening on port " + (process.env.Port || 3000));
})



//vercel 

if (process.env.NODE_ENV == 'production') {
    const path = require('path')
    app.use(express.static(path.join(__dirname, "./public")));

    app.get("*", function (_, res) {
        res.sendFile(
            path.join(__dirname, "./public/index.html"),
            function (err) {
                if (err) {
                    res.status(500).send(err)
                }
            }
        )
    })
}

//-socket setUp in server.js-//
const io = require('socket.io')(http);
io.on('connection', (socket) => {
    console.log('Connected')

    socket.on('message', (msg) => {
        socket.broadcast.emit('message', msg)
    });
}); 