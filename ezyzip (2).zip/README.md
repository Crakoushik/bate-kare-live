# Baate Kare App:
-> It's a real time chat app using nodejs and socket.io

